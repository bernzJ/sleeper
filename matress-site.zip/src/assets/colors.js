const Colors = {
  primary: "#394b63",
  secondary: "#f5f4f2",
  font: "#fff",
};

export default Colors;